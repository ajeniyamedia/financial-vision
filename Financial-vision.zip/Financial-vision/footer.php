<div class="section6">
    <div class="container">      
      <div class="section6Rapper">
        <div class="col-xs-6">
          <h1>Sign Up</h1>
          <div class="section6Content">
            <p>Get subscriber only insights & news 
                delivered by John Doe
            </p>
          </div>
          <div class="section6form">
            <form>
              <p><input type="email" class="section6formfield" id="exampleInputEmail1" placeholder="Enter Your E-mail">
                <button type="submit" class="section6formSubmit">Submit</button>
              </p>
            </form>
        </div>
        </div>
        <div class="col-xs-6">
          <h1>Contact Me</h1>
          <p class="addessInfo"><span>E-mail</span> JohnDoe@demolink.org</p>
          <p class="addessInfo"><span>Telephone</span> +1 959 603 6035</p>
          <p class="addessInfo"><span>Adress</span> 222 Fashion Lane, Ste. 207 Tustin, CA 92780</p>

        </div>
      </div>
    </div>
</div>

<div class="section7">
    <div class="container">      
      <div class="section7Rapper">
        <div class="col-md-6">
          <p class="foterContent">Investments products and services available only to residents of : Arizona - AZ, California - CA, Hawaii - HI, Idaho - ID, New Jersey - NJ, New Mexico - NM, Oregon - OR, Washington - WA Securities and Investment Advice through John Doe & Company, A registered broker/dealer and Investment Advisor, Member FINRA and SIPC. 101 Serious Road, Fincity, FL 32707 Tel: (959) 603- 6035.| John Doe Financial Advisors is not an affiliate of Wall Street Company.
          </p>
          <p class="foterContent">All other trademarks and copyrights are the properties of their respective holders. This website provides information related to the subjects covered. Before making any financial or legal decisions, a professional should be consulted.
          </p>
          <p class="copyright">COPYRIGHT © 2016 | <a href="">PRIVACY POLICY </a></p>
        </div>
        <div class="col-md-3 footerlinks">
          <p class="footerLinkhead">Financial Planning</p>
          <p><a href="">Investment Management</a></p>
          <p><a href="">Retirement Planning</a></p>
          <p><a href="">Long Term Care</a></p>
          <p><a href="">Estate Planning</a></p>
          <p><a href="">Social Security</a></p>
        </div>
        <div class="col-md-3 footerlinks">
          <p class="footerLinkhead">Investment Help</p>
          <p><a href="">Wealth Management</a></p>
          <p><a href="">Retirement & College</a></p>
          <p><a href="">Savings Business Owners</a></p>
          <p><a href="">Insurance & Annuities</a></p>
          <p><a href="">Cash & Credit</a></p>
          <p><a href="">Stocks, Bonds & Mutual Funds</a></p>
        </div>
      </div>
    </div>
</div>
  </div>
  </body>
</html>
    
    



    